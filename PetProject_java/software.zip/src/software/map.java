package software;

import java.awt.Image;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class map extends JPanel {

	public map() {
		// �̹��� �ޱ�
		JLabel img = new JLabel();
		ImageIcon m = new ImageIcon("./image/3.jpg");
		Image m1 = m.getImage();
		Image changeImg = m1.getScaledInstance(380, 342, Image.SCALE_SMOOTH);
		m = new ImageIcon(changeImg);
		img.setIcon(m);
		setLayout(null);
		setBounds(0, 0, 380, 340);
		add(img);
		img.setBounds(0, 0, 380, 340);

//		try {
//			String imageUrl = "http://maps.google.com/staticmap?center=40,26&zoom=1&size=150x112&maptype=satellite&key=ABQIAAAAgb5KEVTm54vkPcAkU9xOvBR30EG5jFWfUzfYJTWEkWk2p04CHxTGDNV791-cU95kOnweeZ0SsURYSA&format=jpg";
//			String destinationFile = "image.jpg";
//			String str = destinationFile;
//			URL url = new URL(imageUrl);
//			InputStream is = url.openStream();
//			OutputStream os = new FileOutputStream(destinationFile);
//
//			byte[] b = new byte[2048];
//			int length;
//
//			while ((length = is.read(b)) != -1) {
//				os.write(b, 0, length);
//			}
//
//			is.close();
//			os.close();
//		} catch (IOException e) {
//			e.printStackTrace();
//			System.exit(1);
//		}
//
//		add(new JLabel(new ImageIcon(
//				(new ImageIcon("image.jpg")).getImage().getScaledInstance(630, 600, java.awt.Image.SCALE_SMOOTH))));
//
//		setVisible(true);
//		pack();

	}

	private void pack() {
		// TODO Auto-generated method stub

	}

}
