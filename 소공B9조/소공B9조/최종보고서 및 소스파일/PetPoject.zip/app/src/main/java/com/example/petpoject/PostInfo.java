package com.example.petpoject;

public class PostInfo {

    private String _title;
    private String _contents;
    private String _postNumber;

    public String getTitle(){return _title;}
    public void set_title(String title){this._title = _title;}
    public String get_contents(){return _contents;}
    public void set_contents(String contents){this._contents = contents;}
    public String getPostNumber(){return _postNumber;}
    public void setPostNumber(String postNumber){this._postNumber = postNumber;}
}
